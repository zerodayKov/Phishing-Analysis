# Phishing Investigation Report — Sample-1070-b (Ourocard PDF Attachment Lure)

**Source:** `phishing_pot/email/sample-1070b.eml`

## 1. Executive Summary

A phishing email impersonating the Ourocard bank card brand (Banco do Brasil) was
investigated. Unlike the two prior samples, this one passes SPF, DKIM, and DMARC in full
because it was sent through a genuine — likely compromised or purpose-created — Gmail
account. The email delivers its payload via a randomly-named PDF attachment rather than
a link.

**Verdict:** Malicious — brand impersonation with suspicious attachment delivery.
**Confidence:** High.

## 2. Header Findings

```
spf=pass (sender IP is 209.85.166.50) smtp.mailfrom=gmail.com
dkim=pass header.d=gmail.com
dmarc=pass header.from=gmail.com
```

All three authentication checks pass, legitimately — the message really was sent through
Google's own mail infrastructure (`mail-io1-f50.google.com`). There is no spoofing at the
protocol level here at all.

**This is the key finding of the set:** authentication headers verify the sending
*infrastructure*, not the sender's *intent*. A phishing email sent from a genuine,
unspoofed Gmail account will pass every automated authentication check every time.

Further up the `Received:` chain, the message was submitted to Gmail from
`d12.domain (52.165.196.181)` — an IP range belonging to Microsoft Azure. The likely
flow: attacker provisions a cloud VM, uses it to log into a Gmail account (stolen,
purchased, or freshly created), and sends through Gmail's legitimate servers to launder
sending reputation and defeat SPF/DKIM/DMARC checks entirely.

The display name — `[ Ourocard - Voce tem pontos ] Protocolo: 57188720698041` —
impersonates the Ourocard brand, but the actual address is a personal Gmail account:
`draftcag@gmail.com`. The fabricated "Protocolo" (reference number) is a common
trust-building trick with no real backing system behind it.

## 3. Attachment Findings

The body (Portuguese) instructs the recipient to redeem accumulated loyalty points, with
the "step-by-step" pushed into an attachment rather than the email body:

```
Content-Type: application/pdf
filename: "FaZXWy1kPmdkSXFDJ.pdf"
```

The filename is a random alphanumeric string with no relation to "Ourocard" or the lure
content — consistent with programmatic, per-recipient generation to defeat hash-based
blocklists.

The PDF's own internal metadata (visible in the raw stream without opening the file)
includes:

```
/Creator(IronPdf)
```

IronPdf is a legitimate developer library for generating PDFs programmatically. Combined
with the randomized filename and a randomized subject-line suffix
(`G3ejrKKzNc30o7qJhZ`), this points to an automated phishing kit producing per-recipient
variants specifically to defeat static signature detection.

**Note:** the attachment was not opened, extracted, or analyzed further — this
investigation is limited to metadata visible without executing or rendering the file.

## 4. Indicators of Compromise (IOCs)

| Type | Indicator | Notes |
|---|---|---|
| Sender address | draftcag@gmail[.]com | Real Gmail account, brand impersonation via display name only |
| Claimed brand | Ourocard (Banco do Brasil) | Not affiliated with sender |
| Relay origin IP | 52.165.196[.]181 | Microsoft Azure range — likely attacker infra submitting to Gmail |
| Attachment filename | FaZXWy1kPmdkSXFDJ.pdf | Randomized, no relation to lure content |
| PDF creator tool | IronPdf | Signals automated/bulk generation |
| Subject randomizer | Trailing string "G3ejrKKzNc30o7qJhZ" | Per-message randomization to evade filters |

## 5. MITRE ATT&CK Mapping

**T1566.001 — Phishing: Spearphishing Attachment** (Initial Access) — the only
attachment-based sample in this set; the other two use link-based delivery (T1566.002).

## 6. Detection Recommendation

Two Sigma rules produced — see [`detections/bank_brand_freemail.yml`](detections/bank_brand_freemail.yml)
and [`detections/pdf_random_filename.yml`](detections/pdf_random_filename.yml).

## 7. Recommended Actions

- Submit the attachment to a sandbox (VirusTotal / any.run) for full detonation rather
  than manual extraction.
- Block the sender address and the Azure source IP.
- Retroactively search for other recipients of the same subject-randomization pattern.
- Use as a case study for "authentication passing ≠ safe" in analyst training material.
