# Ourocard PDF Attachment Phishing Investigation

Single-sample investigation from the phishing-triage-investigations project.
Source sample: `phishing_pot/email/sample-1070b.eml`

- Full report: [`sample-1070b-ourocard-pdf.md`](sample-1070b-ourocard-pdf.md)
- Sigma detection rules: [`detections/`](detections/)

**Why this one stands out:** the email fully passes SPF, DKIM, and DMARC because it was
sent through a genuine Gmail account — demonstrating that authentication passing does
not guarantee an email is safe. Delivery vector is a randomly-named PDF attachment
(MITRE ATT&CK T1566.001), generated via the IronPdf library, consistent with an
automated phishing kit.
